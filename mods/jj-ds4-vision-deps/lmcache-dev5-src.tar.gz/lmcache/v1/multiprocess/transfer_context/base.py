# SPDX-License-Identifier: Apache-2.0
"""Non-GPU context abstractions and utilities for multiprocess transport.

This module provides:
- ``EngineDrivenContextMetadata``: layout metadata dataclass for non-CUDA workers.
- ``EngineDrivenContext``: abstract base class with a two-phase prepare/commit
  interface for CPU-side KV data transfer. Concrete implementations (e.g.
  ``EngineDrivenContextPickle``) each decide *how* data is serialised and transported.
- ``create_engine_driven_context()``: factory that returns the appropriate
  ``EngineDrivenContext`` subclass.
- ``compute_kv_layout``, ``gather_paged_kv_to_cpu``, ``scatter_cpu_to_paged_kv``:
  shared gather/scatter utilities used by all concrete implementations.
"""

# Future
from __future__ import annotations

# Standard
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING
import inspect

# Third Party
import numpy as np
import torch

# First Party
from lmcache import torch_dev
from lmcache.logging import init_logger
from lmcache.utils import EngineType
from lmcache.v1.distributed.api import MemoryLayoutDesc
from lmcache.v1.gpu_connector.utils import LayoutHints
from lmcache.v1.multiprocess.custom_types import (
    EngineDrivenGroupLayout,
    IPCCacheServerKey,
)
from lmcache.v1.multiprocess.mq import MessageQueueClient
import lmcache.lmcache_native as lmcache_native

if TYPE_CHECKING:
    # First Party
    from lmcache.v1.gpu_connector.kv_format.types import DiscoverableKVCache

logger = init_logger(__name__)


@dataclass
class PagedKVTransferWorkspace:
    """Persistent CUDA arguments for engine-driven paged-KV transfers.

    The paged-cache pointer table is immutable for the lifetime of a registered
    engine. Block IDs change for every cache object, so each in-flight store
    receives a distinct pinned-host and device staging pair. One staging tensor
    holds the four objects supported by a native transfer launch.
    """

    paged_buffer_ptrs: torch.Tensor
    block_ids_host: tuple[torch.Tensor, ...]
    block_ids_device: tuple[torch.Tensor, ...]

    @property
    def num_slots(self) -> int:
        """Return the number of independent in-flight staging pairs."""
        return len(self.block_ids_host)


def create_paged_kv_transfer_workspace(
    kv_caches: dict[str, torch.Tensor],
    max_block_ids: int,
    num_slots: int,
    layout_hints: LayoutHints | None = None,
    engine_kv_format: "lmcache_native.EngineKVFormat" | None = None,
) -> PagedKVTransferWorkspace:
    """Create immutable pointer metadata and reusable block-ID staging.

    Args:
        kv_caches: Per-layer tensors belonging to one transfer group.
        max_block_ids: Maximum block-ID count passed to one native launch.
        num_slots: Number of stores that may be in flight concurrently.
        layout_hints: Optional engine layout hints.
        engine_kv_format: Optional pre-detected KV format.

    Returns:
        Workspace whose tensors stay alive until the transfer context closes.
    """
    if max_block_ids < 1:
        raise ValueError("max_block_ids must be positive")
    if num_slots < 1:
        raise ValueError("num_slots must be positive")

    # First Party
    from lmcache.v1.gpu_connector.utils import (
        get_device,
        get_group_data_ptrs,
        get_num_layers,
        normalize_kv_and_discover_format,
    )

    tensors = list(kv_caches.values())
    discovered_format, normalized = normalize_kv_and_discover_format(
        tensors, EngineType.VLLM, layout_hints=layout_hints
    )
    transfer_format = engine_kv_format or discovered_format
    num_layers = get_num_layers(normalized, transfer_format)
    pointer_values = np.array(
        get_group_data_ptrs(normalized, transfer_format, list(range(num_layers))),
        dtype=np.uint64,
    ).view(np.int64)
    device = get_device(normalized)
    paged_buffer_ptrs = torch.from_numpy(pointer_values).to(device=device)
    block_ids_host = tuple(
        torch.empty(max_block_ids, dtype=torch.int64, device="cpu", pin_memory=True)
        for _ in range(num_slots)
    )
    block_ids_device = tuple(
        torch.empty(max_block_ids, dtype=torch.int64, device=device)
        for _ in range(num_slots)
    )
    return PagedKVTransferWorkspace(
        paged_buffer_ptrs=paged_buffer_ptrs,
        block_ids_host=block_ids_host,
        block_ids_device=block_ids_device,
    )


# ---------------------------------------------------------------------------
# Global capability flag: does device_ops.multi_layer_block_kv_transfer accept
# list[torch.Tensor] directly for lmcache_objects_ptrs, or only list[int]?
#
# We inspect the function signature once at import time. If the annotation
# for ``lmcache_objects_ptrs`` includes ``Tensor``, the op can handle tensors
# natively and we pass them through. Otherwise (annotation is list[int], or
# inspect fails entirely) we must convert tensors to data pointers before
# calling.
# ---------------------------------------------------------------------------
def _detect_block_transfer_accepts_tensor() -> bool:
    """Return True if device_ops.multi_layer_block_kv_transfer accepts
    list[torch.Tensor] for its lmcache_objects_ptrs parameter."""
    try:
        # First Party
        from lmcache import device_ops as _device_ops

        fn = _device_ops.multi_layer_block_kv_transfer

        # Attempt: use inspect.signature (works on newer pybind11 builds)
        # Assumptions: if lmcache_objects_ptrs accepts tensors,
        # it's fallback path, and we do not convert tensors to ptrs explicitly.
        # TODO: String matching on annotations is fragile. Wait for device_ops to
        # expose a direct version flag (e.g., device_ops.__version__) or
        # an explicit capability boolean.
        try:
            sig = inspect.signature(fn)
            param = sig.parameters.get("lmcache_objects_ptrs")
            if param is not None and param.annotation is not inspect.Parameter.empty:
                ann_str = str(param.annotation)
                if "Tensor" in ann_str:
                    return True
                # Annotation exists but no Tensor mention → ptr-only
                return False
        except (ValueError, TypeError):
            pass

    except Exception:
        # Import failed or any other error → conservative: assume ptr-only
        pass

    # Default: inspect failed or device_ops not available → assume ptr-only
    return False


_LMC_OPS_BLOCK_TRANSFER_ACCEPTS_TENSOR: bool = _detect_block_transfer_accepts_tensor()
"""If True, ``device_ops.multi_layer_block_kv_transfer`` accepts
``list[torch.Tensor]`` directly for ``lmcache_objects_ptrs``.
If False, callers must convert tensors to ``list[int]`` data pointers."""

logger.info(
    "multi_layer_block_kv_transfer mode: %s",
    "tensor" if _LMC_OPS_BLOCK_TRANSFER_ACCEPTS_TENSOR else "ptr",
)


def _tensors_to_ptrs(tensors: list[torch.Tensor]) -> list[int]:
    """Convert a list of tensors to a list of their data_ptr() values."""
    return [t.data_ptr() for t in tensors]


# ---------------------------------------------------------------------------


@dataclass
class EngineDrivenContextMetadata:
    """Non-GPU context layout metadata for non-CUDA workers.

    Attributes:
        layout_desc: Memory layout descriptor used to interpret chunk payloads.
        block_size: Number of tokens per paged block.
        use_mla: Whether the worker KV format is MLA.
    """

    layout_desc: MemoryLayoutDesc
    block_size: int
    use_mla: bool
    group_layouts: tuple[EngineDrivenGroupLayout, ...] = ()

    @property
    def effective_group_layouts(self) -> tuple[EngineDrivenGroupLayout, ...]:
        """Return explicit groups, or synthesize the legacy single group."""
        if self.group_layouts:
            return self.group_layouts
        shape = tuple(self.layout_desc.shapes[0])
        dtype_str = str(self.layout_desc.dtypes[0]).removeprefix("torch.")
        return (
            EngineDrivenGroupLayout(
                object_group_id=0,
                engine_group_idx=0,
                layer_indices=(),
                tokens_per_block=self.block_size,
                blocks_per_chunk=max(1, shape[-2] // self.block_size),
                shape=shape,
                dtype_str=dtype_str,
            ),
        )


class StoreAdmissionRejected(RuntimeError):
    """Nonfatal server-side cache-store admission rejection."""

    def __init__(self, reason: str) -> None:
        """Initialize the rejection with its stable server reason."""
        self.reason = reason
        super().__init__(f"engine-driven store admission rejected: {reason}")


class EngineDrivenContext(ABC):
    """Abstract base class for CPU-side KV data transfer contexts.

    All concrete implementations share a common message-queue client and
    expose a uniform two-phase ``prepare/commit`` interface so that the
    worker adapter is implementation-agnostic.

    Args:
        metadata: Layout metadata describing the chunk format.
        mq_client: Message-queue client used for server communication.
        mq_timeout: Timeout in seconds for blocking MQ requests.
    """

    def __init__(
        self,
        metadata: EngineDrivenContextMetadata,
        mq_client: MessageQueueClient,
        mq_timeout: float,
        use_retrieve_session_reference: bool = False,
    ) -> None:
        self.metadata = metadata
        self.mq_client = mq_client
        self.mq_timeout = mq_timeout
        self.use_retrieve_session_reference = use_retrieve_session_reference

    @property
    def layout_desc(self) -> MemoryLayoutDesc:
        """The memory layout descriptor for this context."""
        return self.metadata.layout_desc

    def retrieve_rpc_key(self, key: IPCCacheServerKey) -> IPCCacheServerKey:
        """Return the server-compatible key for retrieve prepare and commit."""
        if self.use_retrieve_session_reference:
            return key.as_retrieve_session_reference()
        return key

    @abstractmethod
    def prepare_store(
        self, key: IPCCacheServerKey, instance_id: int
    ) -> tuple[list[torch.Tensor], list[int]] | None:
        """Prepare SHM buffers for a store operation.

        Returns:
            None: pickle mode — no pre-allocated buffers. Caller gathers all
                chunks to CPU itself and sends the serialized data via
                commit_store.
            ([], []): SHM mode but all chunks already cached. Caller should
                skip gather and commit entirely.
            (tensors, chunk_indices): SHM mode with new chunks to write.
                - tensors[i] is a writable SHM-backed buffer for one chunk.
                - chunk_indices[i] is the position of that chunk in the full
                  block_ids sequence (e.g. [0, 2] means only chunks 0 and 2
                  need writing; chunk 1 is already cached).
                Caller gathers only these chunks into the provided tensors,
                then calls commit_store with empty payload.
        """
        ...

    @abstractmethod
    def commit_store(
        self, key: IPCCacheServerKey, instance_id: int, chunks: list[torch.Tensor]
    ) -> bool:
        """Commit store. Pickle: serialize and send. Shm: notify server."""
        ...

    def abort_store(self, key: IPCCacheServerKey, instance_id: int) -> bool:
        """Cancel prepared store reservations; pickle has none to cancel."""
        return True

    @abstractmethod
    def prepare_retrieve(
        self, key: IPCCacheServerKey, instance_id: int
    ) -> list[torch.Tensor] | None:
        """Prepare retrieve. Returns chunks or shm views, or None on miss."""
        ...

    @abstractmethod
    def commit_retrieve(self, key: IPCCacheServerKey, instance_id: int) -> bool:
        """Commit retrieve. Pickle: no-op. Shm: release read locks."""
        ...

    def prepare_store_grouped(
        self, key: IPCCacheServerKey, instance_id: int
    ) -> tuple[list[list[torch.Tensor]], list[list[int]]] | None:
        """Prepare group-major store buffers for a hybrid registration."""
        raise NotImplementedError

    def commit_store_grouped(
        self,
        key: IPCCacheServerKey,
        instance_id: int,
        chunks: list[list[torch.Tensor]],
    ) -> bool:
        """Commit a group-major store payload for a hybrid registration."""
        raise NotImplementedError

    def prepare_retrieve_grouped(
        self, key: IPCCacheServerKey, instance_id: int
    ) -> list[list[torch.Tensor]] | None:
        """Prepare a group-major retrieve payload for a hybrid registration."""
        raise NotImplementedError

    @abstractmethod
    def close(self) -> None:
        """Release any resources held by this context."""
        ...


def create_engine_driven_context(
    metadata: EngineDrivenContextMetadata,
    mq_client: MessageQueueClient,
    mq_timeout: float,
    shm_name: str,
    pool_size: int,
    *,
    use_pickle: bool = False,
    use_retrieve_session_reference: bool = False,
) -> EngineDrivenContext:
    """Factory that returns the appropriate :class:`EngineDrivenContext` implementation.

    Returns SHM-based implementation when shared-memory pool information is
    available; otherwise falls back to the pickle-based implementation.
    If SHM initialization fails for any reason (e.g. segment not found,
    permission error), gracefully falls back to pickle transport.

    Args:
        metadata: Layout metadata for the non-GPU context.
        mq_client: Message-queue client for server communication.
        mq_timeout: Timeout in seconds for blocking MQ requests.
        shm_name: Shared-memory segment name. Empty values force pickle mode.
        pool_size: Shared-memory pool size in bytes. Non-positive values force
            pickle mode.
        use_pickle: Explicitly use pickle transport even when SHM info is
            available.
        use_retrieve_session_reference: Omit token IDs from post-lookup
            retrieve RPCs when the server advertises support.

    Returns:
        A concrete :class:`EngineDrivenContext` instance.
    """
    if not shm_name or pool_size <= 0:
        use_pickle = True

    if not use_pickle:
        # Local
        from .shm import EngineDrivenContextShm

        try:
            logger.info(
                "Creating EngineDrivenContextShm (shm_name=%s, pool_size=%d)",
                shm_name,
                pool_size,
            )
            return EngineDrivenContextShm(
                metadata,
                mq_client,
                mq_timeout,
                shm_name,
                pool_size,
                use_retrieve_session_reference=use_retrieve_session_reference,
            )
        except Exception:
            logger.warning(
                "Failed to initialize SHM context (shm_name=%s), "
                "falling back to pickle transport",
                shm_name,
                exc_info=True,
            )

    # Local
    from .pickle import EngineDrivenContextPickle

    logger.info("Creating EngineDrivenContextPickle (pickle transport)")
    return EngineDrivenContextPickle(
        metadata,
        mq_client,
        mq_timeout,
        use_retrieve_session_reference=use_retrieve_session_reference,
    )


# ---------------------------------------------------------------------------
# Shared gather / scatter utilities
# ---------------------------------------------------------------------------


def compute_kv_layout(
    kv_caches: dict[str, torch.Tensor],
    layout_hints: LayoutHints | None = None,
) -> tuple[int, int, int, str, "lmcache_native.EngineKVFormat", int]:
    """Compute KV layout metadata from KV tensors.

    Args:
        kv_caches: Per-layer KV tensor mapping.
        layout_hints: Optional engine layout hints.

    Returns:
        Tuple of ``(block_size, num_layers, hidden_dim_size, dtype_str,``
        ``engine_kv_format, kv_size)``. ``hidden_dim_size`` is the per-token
        object width (``num_heads * head_size``; for fused-K/V formats the
        head size is the packed ``2 * head_size``) and ``kv_size`` is the
        object plane count (1 for MLA and fused-K/V, else 2).

    Raises:
        ValueError: If ``kv_caches`` is empty.
    """
    # First Party
    from lmcache.v1.gpu_connector.utils import (
        get_block_size,
        get_dtype,
        get_head_size,
        get_kv_size,
        get_num_heads,
        get_num_layers,
        normalize_kv_and_discover_format,
    )

    tensors = list(kv_caches.values())
    if not tensors:
        raise ValueError("kv_caches is empty. Cannot compute KV layout.")

    engine_kv_format, normalized = normalize_kv_and_discover_format(
        tensors, EngineType.VLLM, layout_hints=layout_hints
    )
    block_size = get_block_size(normalized, engine_kv_format)
    num_layers = get_num_layers(normalized, engine_kv_format)
    hidden_dim_size = get_num_heads(normalized, engine_kv_format) * get_head_size(
        normalized, engine_kv_format
    )
    kv_size = get_kv_size(normalized, engine_kv_format)
    dtype_str = str(get_dtype(normalized, engine_kv_format)).replace("torch.", "")
    return (
        block_size,
        num_layers,
        hidden_dim_size,
        dtype_str,
        engine_kv_format,
        kv_size,
    )


def _resolve_uniform_block_stride(
    normalized: DiscoverableKVCache,
    engine_kv_format: lmcache_native.EngineKVFormat,
    num_layers: int,
    group_idx: int,
) -> int | None:
    """Resolve one authoritative physical block stride for a transfer group.

    Args:
        normalized: Actual normalized tensors passed to the transfer operation.
        engine_kv_format: Format used to interpret ``normalized``.
        num_layers: Number of layers in the transfer group.
        group_idx: Protocol-visible group index used in diagnostics.

    Returns:
        The common physical block stride in elements, or ``None`` when the
        format uses the descriptor's tight-layout fallback.

    Raises:
        ValueError: If layers in the group disagree on physical block stride.
    """
    # First Party
    from lmcache.v1.gpu_connector.utils import (
        resolve_block_stride_and_log_layout,
    )

    layer_strides = [
        resolve_block_stride_and_log_layout(
            normalized,
            engine_kv_format,
            layer_idx=layer_idx,
            group_idx=group_idx,
        )
        for layer_idx in range(num_layers)
    ]
    if len(set(layer_strides)) > 1:
        raise ValueError(
            f"engine-driven group {group_idx} layers disagree on physical "
            f"block stride: {layer_strides}"
        )
    return layer_strides[0] if layer_strides else None


def gather_paged_kv_to_cpu(
    kv_caches: dict[str, torch.Tensor],
    block_ids: list[int],
    blocks_per_chunk: int,
    layout_hints: LayoutHints | None = None,
    engine_kv_format: "lmcache_native.EngineKVFormat" | None = None,
    out: list[torch.Tensor] | None = None,
    chunk_indices: list[int] | None = None,
    blocks_per_window: int | None = None,
    group_idx: int = 0,
    transfer_workspace: PagedKVTransferWorkspace | None = None,
    transfer_workspace_slot: int = 0,
) -> list[torch.Tensor]:
    """Gather paged KV blocks into CPU chunk tensors.

    Args:
        kv_caches: Per-layer KV tensor mapping.
        block_ids: Flattened block IDs for all chunks.
        blocks_per_chunk: Number of paged blocks in one LMCache chunk.
        layout_hints: Optional engine layout hints.
        engine_kv_format: Optional pre-detected KV format.
        out: Optional pre-allocated output tensors.  If provided, length
            must be at least ``len(chunk_indices)`` when ``chunk_indices``
            is given, or the total number of chunks otherwise.  Any extra
            buffers beyond the number of gathered chunks are ignored.
        chunk_indices: Optional list of chunk positions (into the full
            ``block_ids`` sequence) to gather.  When provided together with
            ``out``, only those chunks are gathered and written into
            ``out[i]`` in order.  When ``None``, all chunks are gathered
            (backward-compatible behaviour).
        blocks_per_window: Number of trailing physical blocks retained from
            each logical chunk. ``None`` stores the whole chunk.
        group_idx: Protocol-visible group index used in layout diagnostics.
        transfer_workspace: Optional registered CUDA pointer table and reusable
            block-ID staging. When omitted, CUDA tensors are allocated for
            backward compatibility.
        transfer_workspace_slot: Staging pair reserved for this in-flight
            transfer.

    Returns:
        List of CPU tensors, one per chunk. For split-K/V formats each chunk
        has shape ``[2, num_layers, chunk_tokens, hidden_dim]`` where
        dimension ``0`` stores ``(K, V)``. For single-plane formats
        (``kv_size == 1``: MLA and fused-K/V) each chunk has shape
        ``[num_layers, chunk_tokens, num_heads * head_size]`` — for fused
        formats ``head_size`` is the packed ``2 * head_size``.

    Raises:
        ValueError: If ``out`` is provided with fewer buffers than the number
            of gathered chunks, or group layers disagree on physical block
            stride.
    """
    # First Party
    from lmcache import device_ops
    from lmcache.v1.gpu_connector.utils import (
        get_block_size,
        get_device,
        get_dtype,
        get_group_data_ptrs,
        get_head_size,
        get_kv_size,
        get_num_blocks,
        get_num_heads,
        get_num_layers,
        make_page_buffer_shape_desc,
        normalize_kv_and_discover_format,
    )

    tensors = list(kv_caches.values())
    fmt, normalized = normalize_kv_and_discover_format(
        tensors, EngineType.VLLM, layout_hints=layout_hints
    )
    if engine_kv_format is None:
        engine_kv_format = fmt

    block_size = get_block_size(normalized, engine_kv_format)
    num_layers = get_num_layers(normalized, engine_kv_format)
    content_size = get_num_heads(normalized, engine_kv_format) * get_head_size(
        normalized, engine_kv_format
    )
    num_blocks = get_num_blocks(normalized, engine_kv_format)
    num_chunks = len(block_ids) // blocks_per_chunk
    bpw = blocks_per_chunk if blocks_per_window is None else blocks_per_window
    if bpw < 1 or bpw > blocks_per_chunk:
        raise ValueError(
            f"blocks_per_window must be in [1, {blocks_per_chunk}], got {bpw}"
        )
    window_tokens = bpw * block_size

    block_stride_elems = _resolve_uniform_block_stride(
        normalized,
        engine_kv_format,
        num_layers,
        group_idx,
    )
    shape_desc = make_page_buffer_shape_desc(
        normalized,
        engine_kv_format,
        layer_idx=0,
        num_layers_in_group=num_layers,
        num_blocks=num_blocks,
        block_size=block_size,
        block_stride_elems=block_stride_elems,
    )

    iter_indices = (
        list(chunk_indices) if chunk_indices is not None else list(range(num_chunks))
    )
    # Require at least one output buffer per gathered chunk. Extra trailing
    # buffers are ignored (see ``chunks = out[: len(iter_indices)]`` below),
    # mirroring the scatter-side length check for consistency.
    if out is not None and len(out) < len(iter_indices):
        raise ValueError(
            f"out length ({len(out)}) must be at least the number of "
            f"gathered chunks ({len(iter_indices)})"
        )

    # Determine if pinned memory is strictly required
    # (only for the compiled C++ path which does not accept tensor)
    requires_pinned = not _LMC_OPS_BLOCK_TRANSFER_ACCEPTS_TENSOR
    needs_staging = False
    staged_chunks = []

    if out is None:
        # One object plane per K/V entry: MLA and fused-K/V formats
        # (kv_size == 1) store a single plane, split formats store K and V.
        if get_kv_size(normalized, engine_kv_format) == 1:
            chunks = [
                torch.empty(
                    (num_layers, window_tokens, content_size),
                    dtype=get_dtype(normalized, engine_kv_format),
                    device=torch.device("cpu"),
                    pin_memory=requires_pinned,
                )
                for _ in iter_indices
            ]
        else:
            chunks = [
                torch.empty(
                    (2, num_layers, window_tokens, content_size),
                    dtype=get_dtype(normalized, engine_kv_format),
                    device=torch.device("cpu"),
                    pin_memory=requires_pinned,
                )
                for _ in iter_indices
            ]
    else:
        _target_out = out[: len(iter_indices)]

        if requires_pinned and not all(t.is_pinned() for t in _target_out):
            # Core fallback: Unpinned memory (e.g., IPC Shared Memory) detected.
            # We cannot dynamically call `.pin_memory()` on `out` because it
            # would allocate new tensors, breaking the caller's expectation
            # of an in-place update. Instead, we allocate a temporary pinned
            # staging buffer for the C++ kernel to write to safely.
            logger.warning(
                "Unpinned memory detected in 'out' during "
                "gather_paged_kv_to_cpu (likely Shared Memory). "
                "Using an internal pinned staging buffer, which "
                "adds a CPU memory copy overhead."
            )
            needs_staging = True
            staged_chunks = [torch.empty_like(t, pin_memory=True) for t in _target_out]
            chunks = (
                staged_chunks  # Point to the safe staging buffer for the H2D transfer
            )
        else:
            # Ideal case: Memory is pinned, or we are using Python fallback.
            # Ignore any extra trailing buffers beyond what we actually gather so
            # the kernel's ``total_blocks % num_objects`` invariant still holds.
            # Return ``out`` unchanged when no trimming is needed so the in-place
            # fill contract (result is out) is preserved.
            if len(out) == len(iter_indices):
                chunks = out
            else:
                chunks = out[: len(iter_indices)]

    selected_block_ids: list[int] = []
    for chunk_idx in iter_indices:
        chunk_end = (chunk_idx + 1) * blocks_per_chunk
        selected_block_ids.extend(block_ids[chunk_end - bpw : chunk_end])

    if selected_block_ids:
        if _LMC_OPS_BLOCK_TRANSFER_ACCEPTS_TENSOR:
            # Python fallback: accepts tensor list directly for all params.
            paged_arg = normalized
            objs_arg = chunks
            block_ids_arg = selected_block_ids

            # call kernel in one shot
            device_ops.multi_layer_block_kv_transfer(
                paged_arg,
                objs_arg,
                block_ids_arg,
                get_device(normalized),
                lmcache_native.TransferDirection.D2H,
                shape_desc,
                window_tokens,
                engine_kv_format,
                0,
            )

        else:
            # Compiled C++/CUDA/XPU: requires int64 pointer tensor and list[int].
            if transfer_workspace is None:
                _ptrs_np = np.array(
                    get_group_data_ptrs(
                        normalized, engine_kv_format, list(range(num_layers))
                    ),
                    dtype=np.uint64,
                ).view(np.int64)
                paged_arg = torch.from_numpy(_ptrs_np).to(device=get_device(normalized))
                block_ids_arg = torch.tensor(
                    selected_block_ids,
                    dtype=torch.int64,
                    device=get_device(normalized),
                )
                block_ids_host = None
                block_ids_device = None
            else:
                if not 0 <= transfer_workspace_slot < transfer_workspace.num_slots:
                    raise ValueError(
                        f"transfer_workspace_slot {transfer_workspace_slot} is "
                        f"outside [0, {transfer_workspace.num_slots})"
                    )
                paged_arg = transfer_workspace.paged_buffer_ptrs
                block_ids_arg = None
                block_ids_host = transfer_workspace.block_ids_host[
                    transfer_workspace_slot
                ]
                block_ids_device = transfer_workspace.block_ids_device[
                    transfer_workspace_slot
                ]

            # This safely points to either the pre-pinned chunks
            # OR the temporary staged_chunks
            objs_arg = _tensors_to_ptrs(chunks)

            # Split transfer to respect CUDA kernel's object count limitation
            MAX_OBJECTS = 4
            req_blocks_per_obj = bpw
            total_objects = len(objs_arg)

            for i in range(0, total_objects, MAX_OBJECTS):
                # Slice object pointers and corresponding block IDs
                batch_objs_ptrs = objs_arg[i : i + MAX_OBJECTS]

                start_block = i * req_blocks_per_obj
                end_block = min(
                    (i + MAX_OBJECTS) * req_blocks_per_obj, len(selected_block_ids)
                )
                if transfer_workspace is None:
                    assert block_ids_arg is not None
                    batch_blocks = block_ids_arg[start_block:end_block]
                else:
                    assert block_ids_host is not None
                    assert block_ids_device is not None
                    batch_ids = selected_block_ids[start_block:end_block]
                    batch_count = len(batch_ids)
                    if batch_count > block_ids_host.numel():
                        raise ValueError(
                            f"transfer workspace holds {block_ids_host.numel()} "
                            f"block IDs, but the launch requires {batch_count}"
                        )
                    block_ids_host[:batch_count].numpy()[:] = batch_ids
                    block_ids_device[:batch_count].copy_(
                        block_ids_host[:batch_count], non_blocking=True
                    )
                    batch_blocks = block_ids_device[:batch_count]

                # Execute batched transfer
                device_ops.multi_layer_block_kv_transfer(
                    paged_arg,
                    batch_objs_ptrs,
                    batch_blocks,
                    get_device(normalized),
                    lmcache_native.TransferDirection.D2H,
                    shape_desc,
                    window_tokens,
                    engine_kv_format,
                    0,
                )

    # --- Final reconciliation ---
    # If we used a staging buffer to protect unpinned shared memory,
    # we now copy the gathered data back into the caller's original tensors.
    if needs_staging:
        assert out is not None
        # The CPU MUST block and wait for the GPU ONLY when a temporary
        # staging buffer is used. This is because the CPU needs to immediately
        # read this data for the memory copy below.
        torch_dev.synchronize()

        for dst, src in zip(_target_out, staged_chunks, strict=False):
            dst.copy_(src)  # High-speed CPU-to-CPU memory copy

        if len(out) == len(iter_indices):
            chunks = out
        else:
            chunks = _target_out

    # Fast path: The async GPU copy might still be in progress.
    # We intentionally omit synchronization here for performance.
    # WARNING: The caller MUST explicitly call `torch_dev.synchronize()`
    # before consuming these chunks to ensure data validity.

    return chunks


def scatter_cpu_to_paged_kv(
    kv_caches: dict[str, torch.Tensor],
    block_ids: list[int],
    chunks: list[torch.Tensor],
    blocks_per_chunk: int,
    skip_first_n_tokens: int = 0,
    layout_hints: LayoutHints | None = None,
    engine_kv_format: "lmcache_native.EngineKVFormat" | None = None,
    blocks_per_window: int | None = None,
    group_idx: int = 0,
) -> None:
    """Scatter CPU chunk tensors back into paged KV tensors.

    Args:
        kv_caches: Per-layer KV tensor mapping to write into.
        block_ids: Flattened destination block IDs for all chunks.  Length
            must be at least ``len(chunks) * blocks_per_chunk``; any extra
            trailing block IDs are ignored.
        chunks: List of CPU chunk tensors (as returned by
            :func:`gather_paged_kv_to_cpu`).
        blocks_per_chunk: Number of paged blocks in one LMCache chunk.
        skip_first_n_tokens: Token prefix to skip when scattering.  Must be a
            multiple of ``block_size``; non-aligned values are rounded down
            to the nearest whole block and an error is logged (matching the
            GPU transfer path).
        layout_hints: Optional engine layout hints.
        engine_kv_format: Optional pre-detected KV format.
        blocks_per_window: Number of trailing physical blocks represented by
            each stored chunk. ``None`` means the whole logical chunk.
        group_idx: Protocol-visible group index used in layout diagnostics.

    Raises:
        ValueError: If ``block_ids`` is shorter than
            ``len(chunks) * blocks_per_chunk``, or group layers disagree on
            physical block stride.

    Notes:
        Raw-pointer transfers from locally pinned temporary buffers complete
        before this function returns or propagates a transfer exception.
        Caller-owned pinned buffers remain asynchronous: the caller must keep
        them alive and synchronize before consuming the destination KV.
    """
    # First Party
    from lmcache import device_ops
    from lmcache.v1.gpu_connector.utils import (
        get_block_size,
        get_device,
        get_group_data_ptrs,
        get_num_blocks,
        get_num_layers,
        make_page_buffer_shape_desc,
        normalize_kv_and_discover_format,
    )

    if not chunks:
        return
    # Require enough block IDs to cover every chunk. Extra trailing block IDs
    # are ignored by the per-chunk slicing below, mirroring the gather-side
    # ``out`` length check for consistency.
    if len(block_ids) < len(chunks) * blocks_per_chunk:
        raise ValueError(
            f"block_ids length ({len(block_ids)}) must be at least "
            f"len(chunks) ({len(chunks)}) * blocks_per_chunk "
            f"({blocks_per_chunk})"
        )

    tensors = list(kv_caches.values())
    fmt, normalized = normalize_kv_and_discover_format(
        tensors, EngineType.VLLM, layout_hints=layout_hints
    )
    if engine_kv_format is None:
        engine_kv_format = fmt

    block_size = get_block_size(normalized, engine_kv_format)
    num_layers = get_num_layers(normalized, engine_kv_format)
    num_blocks = get_num_blocks(normalized, engine_kv_format)
    bpw = blocks_per_chunk if blocks_per_window is None else blocks_per_window
    if bpw < 1 or bpw > blocks_per_chunk:
        raise ValueError(
            f"blocks_per_window must be in [1, {blocks_per_chunk}], got {bpw}"
        )
    window_tokens = bpw * block_size

    # Block-level transfer can only skip whole blocks. A non-aligned prefix is
    # rounded down to the nearest block (matching the lmcache-driven path in
    # lmcache_driven_transfer.py) rather than raising, so a slightly misaligned skip
    # degrades gracefully instead of failing the whole retrieve.
    if skip_first_n_tokens % block_size != 0:
        logger.error(
            "skip_first_n_tokens (%d) is not block-aligned (block_size=%d); "
            "rounding down to %d blocks",
            skip_first_n_tokens,
            block_size,
            skip_first_n_tokens // block_size,
        )
    skip_prefix_n_blocks = skip_first_n_tokens // block_size
    full_windows_to_skip, tail_blocks = divmod(skip_prefix_n_blocks, blocks_per_chunk)
    skip_prefix_window = full_windows_to_skip * bpw + max(
        0, tail_blocks - (blocks_per_chunk - bpw)
    )

    block_stride_elems = _resolve_uniform_block_stride(
        normalized,
        engine_kv_format,
        num_layers,
        group_idx,
    )
    shape_desc = make_page_buffer_shape_desc(
        normalized,
        engine_kv_format,
        layer_idx=0,
        num_layers_in_group=num_layers,
        num_blocks=num_blocks,
        block_size=block_size,
        block_stride_elems=block_stride_elems,
    )

    selected_block_ids: list[int] = []
    for chunk_idx in range(len(chunks)):
        chunk_end = (chunk_idx + 1) * blocks_per_chunk
        selected_block_ids.extend(block_ids[chunk_end - bpw : chunk_end])

    if not selected_block_ids:
        return

    # Only the ptr-only branch below pins temporaries; the tensor branch
    # hands torch the chunks directly and keeps them alive itself.
    dynamically_pinned = False
    if _LMC_OPS_BLOCK_TRANSFER_ACCEPTS_TENSOR:
        # Python fallback: accepts tensor list directly for all params.
        paged_arg = normalized
        objs_arg = chunks
        block_ids_arg = selected_block_ids

        device_ops.multi_layer_block_kv_transfer(
            paged_arg,
            objs_arg,
            block_ids_arg,
            get_device(normalized),
            lmcache_native.TransferDirection.H2D,
            shape_desc,
            window_tokens,
            engine_kv_format,
            skip_prefix_window,
        )
    else:
        # assuming this is c ops path which requires pin memory
        # TODO: may have a better approach here
        # Defensive check: Ensure all incoming CPU chunks are pinned memory.
        # Otherwise, the underlying CUDA kernel may throw an Illegal
        # Memory Access error during H2D transfer.
        dynamically_pinned = not all(chunk.is_pinned() for chunk in chunks)
        if dynamically_pinned:
            logger.warning(
                "Received unpinned CPU tensors in scatter_cpu_to_paged_kv. "
                "Dynamically pinning memory now, which may incur additional"
                "synchronization overhead."
            )
            chunks = [
                chunk.pin_memory() if not chunk.is_pinned() else chunk
                for chunk in chunks
            ]

        # Compiled C++/CUDA/XPU: requires int64 pointer tensor and list[int].
        _ptrs_np = np.array(
            get_group_data_ptrs(normalized, engine_kv_format, list(range(num_layers))),
            dtype=np.uint64,
        ).view(np.int64)
        paged_arg = torch.from_numpy(_ptrs_np).to(device=get_device(normalized))
        objs_arg = _tensors_to_ptrs(chunks)
        block_ids_arg = torch.tensor(
            selected_block_ids, dtype=torch.int64, device=get_device(normalized)
        )

        # Batched transfer to satisfy cuda's limitation (max 4 objects)
        MAX_OBJECTS = 4
        req_blocks_per_obj = bpw
        total_chunks = len(chunks)

        h2d_started = False
        try:
            for i in range(0, total_chunks, MAX_OBJECTS):
                # Slice objects and block IDs for this batch
                batch_objs_ptrs = objs_arg[i : i + MAX_OBJECTS]

                start_block = i * req_blocks_per_obj
                end_block = min(
                    (i + MAX_OBJECTS) * req_blocks_per_obj, len(selected_block_ids)
                )
                batch_blocks = block_ids_arg[start_block:end_block]
                batch_skip = max(0, skip_prefix_window - start_block)
                if batch_skip >= len(batch_blocks):
                    continue

                # A native call can enqueue a copy before raising.
                h2d_started = True
                device_ops.multi_layer_block_kv_transfer(
                    paged_arg,
                    batch_objs_ptrs,
                    batch_blocks,
                    get_device(normalized),
                    lmcache_native.TransferDirection.H2D,
                    shape_desc,
                    window_tokens,
                    engine_kv_format,
                    batch_skip,
                )
        finally:
            if dynamically_pinned and h2d_started:
                # Torch cannot track the source lifetime through raw pointers.
                # Drain copies before releasing local temporaries, including
                # when a subsequent batch raises. Caller-owned pinned buffers
                # retain their asynchronous lifetime contract.
                torch_dev.synchronize()
    # Fast path: The async GPU copy might still be in progress.
    # We intentionally omit synchronization here for performance.
    # WARNING: The caller MUST explicitly call `torch_dev.synchronize()`
    # before consuming these chunks to ensure data validity.
